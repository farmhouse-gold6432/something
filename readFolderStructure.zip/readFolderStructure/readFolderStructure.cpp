﻿#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>

namespace fs = std::filesystem;

int main(int argc, char *argv[])
{
    std::cout << "Reading the full directory... this may take some time" << std::endl;

    std::ofstream outputFile("folderStructure.txt");
    std::vector<fs::directory_entry> entries;
    fs::path startPath = fs::current_path();
    std::vector<std::pair<fs::path, std::string>> stack;
    stack.push_back({startPath, ""});

    std::vector<std::string> excludedFolders = {
        "System Volume Information",
        ".Trash-1000",
        "$RECYCLE.BIN",
        ".git",
        ".vs",
        ".vscode",
        ".cmake",
        "CMakeFiles",
        "out",
        "bin",
        "obj"
    };

    while (!stack.empty())
    {
        auto [currentPath, prefix] = stack.back();

        stack.pop_back();
        entries.clear();

        try
        {
            for (const auto &entry : fs::directory_iterator(currentPath))
                entries.push_back(entry);
        }
        catch (const std::exception)
        {
            continue;
        };

        std::sort(entries.begin(), entries.end(), [](const auto &a, const auto &b)
                  { return a.path().filename() < b.path().filename(); });

        for (const auto &entry : entries)
        {
            std::string finalOutput;
            const fs::path &entry_path = entry.path();
            std::string name = entry_path.filename().string();

            if (std::find(excludedFolders.begin(), excludedFolders.end(), name) != excludedFolders.end())
                continue;

            if (!fs::is_symlink(entry_path))
            {
                if (fs::is_directory(entry_path))
                {
                    finalOutput = prefix + name + "/";
                }
                else
                {
                    finalOutput = prefix + name;
                };

                // std::cout << finalOutput << std::endl;
                outputFile << finalOutput << std::endl;

                stack.push_back({entry_path, prefix + "  "});
            };
        };
    };
    outputFile.close();
};